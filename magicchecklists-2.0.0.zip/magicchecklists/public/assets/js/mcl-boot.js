import MagicChecklistDrawer from './mcl-drawer.js';

function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve, reject) => {
    // Check if element already exists
    const element = document.querySelector(selector);
    if (element) {
      console.log(`MCL: Found ${selector} immediately`);
      resolve(element);
      return;
    }

    console.log(`MCL: Waiting for ${selector}...`);

    // Set up observer to watch for the element
    const observer = new MutationObserver((mutations, obs) => {
      const element = document.querySelector(selector);
      if (element) {
        console.log(`MCL: Found ${selector} via MutationObserver`);
        obs.disconnect();
        resolve(element);
      }
    });

    // Start observing
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Set timeout
    const timeoutId = setTimeout(() => {
      console.log(`MCL: Timeout waiting for ${selector}`);
      observer.disconnect();
      reject(new Error(`Element ${selector} not found within ${timeout}ms`));
    }, timeout);
  });
}

async function initializeMagicChecklist() {
  // Clean up old initialization if needed
  if (window.mcl_cleanup) {
    window.mcl_cleanup();
  }

  console.log('MCL: Starting initialization...');
  console.log('MCL: DOM state:', {
    readyState: document.readyState,
    hasDrawer: !!document.querySelector('#mcl-drawer'),
    hasItems: !!document.querySelector('#mcl-items'),
    hasPublicRoot: !!document.querySelector('#mcl-public-root'),
    hasAdminRoot: !!document.querySelector('#mcl-admin-root')
  });

  try {
    // Wait for the essential DOM elements that MagicChecklistDrawer needs
    await waitForElement('#mcl-drawer');
    await waitForElement('#mcl-items');
    
    console.log('MCL: All required elements found, initializing...');
    
    // Initialize new instance only after DOM elements are ready
    if (!window.MagicChecklist) {
      window.MagicChecklist = new MagicChecklistDrawer();
    }

    console.log('MCL: Initialization successful');
    return window.MagicChecklist;
  } catch (error) {
    console.warn('MagicChecklist initialization failed:', error);
    console.warn('Required DOM elements not found. Make sure React components have rendered.');
    console.warn('Current DOM elements:', {
      drawer: !!document.querySelector('#mcl-drawer'),
      items: !!document.querySelector('#mcl-items'),
      publicRoot: !!document.querySelector('#mcl-public-root'),
      adminRoot: !!document.querySelector('#mcl-admin-root'),
      bodyHTML: document.body.innerHTML.substring(0, 500) + '...'
    });
    return null;
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeMagicChecklist);
} else {
  initializeMagicChecklist();
}

// Export for direct usage if needed
export { initializeMagicChecklist };